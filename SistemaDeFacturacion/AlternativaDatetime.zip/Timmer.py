class Calendario:
    
    def __init__(self):
        self.mes = 0
        self.semana = 1
        self.dia = 1 #1=Lunes, 2=Martes....
        self.hora = 0
        self.min = 0

    def pasar_minuto(self):
        self.min += 1
        if self.min == 60:
            self.min = 0
            self.hora += 1
            if self.hora == 24:
                self.hora = 0
                self.dia += 1
                if self.dia == 8:
                    self.dia = 0
                    self.semana += 1
                    if self.demana == 5:
                        self.semana = 0
                        self.mes += 1

yo = Calendario()
counter = 0
while counter < 60:
    yo.pasar_minuto()
    counter += 1
print(yo.hora)
print(yo.min)